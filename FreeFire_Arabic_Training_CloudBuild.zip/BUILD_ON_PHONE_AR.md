# بناء APK من الهاتف بدون Android Studio

1. افتح https://github.com من متصفح الهاتف وسجّل الدخول.
2. أنشئ مستودعاً جديداً (Repository) واجعله Public.
3. ارفع كل محتويات هذا المشروع إلى المستودع، مع مجلد .github.
4. افتح تبويب Actions ثم اختر Build Android APK واضغط Run workflow.
5. بعد نجاح البناء، افتح عملية البناء وانزل إلى Artifacts.
6. حمّل FreeFire-Arabic-Training-APK، وفك ضغطه وثبّت app-debug.apk.

لا ترفع كلمات مرور أو مفاتيح أو بيانات شخصية.
المشروع واجهة وقائمة تدريب بصرية فقط، ولا يتلاعب باللعبة.
