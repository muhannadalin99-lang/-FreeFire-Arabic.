# مساعد التدريب العربي — Free Fire وFree Fire MAX

هذا مشروع Android Studio (Kotlin) وليس ملف APK جاهزاً. يوفر:
- زرين لفتح Free Fire العادية وFree Fire MAX إذا كانت مثبتة.
- قائمة عربية عائمة بإذن الظهور فوق التطبيقات.
- عناصر تدريب بصرية فقط؛ لا يقرأ ذاكرة اللعبة ولا يغيّرها ولا ينفّذ قتلًا تلقائياً.

## إنشاء APK
1. نزّل وثبّت Android Studio على كمبيوتر.
2. افتح مجلد `FreeFire_Arabic_Training_Launcher` عبر **Open**.
3. انتظر Gradle Sync، وثبّت Android SDK 35 وJDK 17 إذا طُلبا.
4. من القائمة اختر **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. ستجد APK عادةً في `app/build/outputs/apk/debug/app-debug.apk`.
6. انقل الملف إلى هاتف Android 13 وثبّته. قد تحتاج السماح بالتثبيت من هذا المصدر.
7. افتح التطبيق، واسمح له بالظهور فوق التطبيقات عند طلب ذلك.

## ملاحظات
- أسماء الحزم المستخدمة: `com.dts.freefireth` للعادية و`com.dts.freefiremax` للـMAX.
- إذا كانت نسخة منطقتك تستخدم معرف حزمة مختلفاً، فقد لا يظهر زر فتحها.
- إنشاء APK من هذا المشروع يحتاج Android Studio على كمبيوتر؛ لا يمكن تثبيت المشروع كأنه APK مباشرة.
